import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import Form from './form';
import Registrationform from './registrationform';

import { ChakraProvider } from '@chakra-ui/react'
import AirbnbCard from './App';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <ChakraProvider>
     {/* <App />  */}
     {/* <Form /> */}
     <Registrationform/>
    {/* <AirbnbCard/> */}
    </ChakraProvider>
   
  </React.StrictMode>
);


